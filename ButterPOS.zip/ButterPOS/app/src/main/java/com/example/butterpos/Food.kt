package com.example.butterpos

data class Food(val foodName:String, val foodImage:Int/*,val foodPrice:Float */) {

}